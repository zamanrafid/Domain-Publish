document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('#navLinks a').forEach((a,i)=> a.style.setProperty('--ni', i));

const navbar = document.getElementById('navbar');
window.addEventListener('scroll', ()=>{ navbar.classList.toggle('scrolled', window.scrollY > 30); });

const menuDotBtn = document.getElementById('menuDotBtn');
const navLinks = document.getElementById('navLinks');
const navbarEl = document.getElementById('navbar');
/* Clear the navbar's entrance transform once it finishes, so the mobile
   .nav-links (position:fixed) anchors to the viewport, not the navbar box. */
if(navbarEl){
  navbarEl.addEventListener('animationend', ()=>{ navbarEl.style.transform = 'none'; });
  setTimeout(()=>{ navbarEl.style.transform = 'none'; }, 2200);
}
function closeMenu(){ navLinks.classList.remove('open'); menuDotBtn.classList.remove('open'); menuDotBtn.setAttribute('aria-expanded','false'); document.body.classList.remove('menu-open'); unlockScroll(); }
function openMenu(){ lockScroll(); navLinks.classList.add('open'); menuDotBtn.classList.add('open'); menuDotBtn.setAttribute('aria-expanded','true'); document.body.classList.add('menu-open'); }
menuDotBtn.addEventListener('click', ()=>{
  if(navLinks.classList.contains('open')) closeMenu(); else openMenu();
});
navLinks.querySelectorAll('a').forEach(a=> a.addEventListener('click', closeMenu));
/* Tap on the empty panel area or press Escape to close */
navLinks.addEventListener('click', (e)=>{ if(e.target === navLinks) closeMenu(); });
  document.addEventListener('keydown', (e)=>{ if(e.key === 'Escape') closeMenu(); });
  /* Tap outside the dropdown (or the menuDotBtn) closes it */
  document.addEventListener('click', (e)=>{
    if(!navLinks.classList.contains('open')) return;
    if(navLinks.contains(e.target) || menuDotBtn.contains(e.target)) return;
    closeMenu();
  });

const sectionIds = ['home','about','skills','services','portfolio','why','contact'];
const railLabels = { home:'Home', about:'About', skills:'Skills', services:'Services', portfolio:'Portfolio', why:'Why Me', contact:'Contact' };
const rail = document.getElementById('rail');
sectionIds.forEach(id=>{
  const dot = document.createElement('div');
  dot.className = 'rail-dot';
  dot.dataset.target = id;
  dot.innerHTML = '<span class="rail-label">'+railLabels[id]+'</span>';
  dot.addEventListener('click', ()=> fxScrollToId('#'+id));
  rail.appendChild(dot);
});
const railDots = rail.querySelectorAll('.rail-dot');
const navA = document.querySelectorAll('#navLinks a');

const io = new IntersectionObserver((entries)=>{
  entries.forEach(entry=>{
    if(entry.isIntersecting){
      const id = entry.target.id;
      railDots.forEach(d=> d.classList.toggle('active', d.dataset.target===id));
      navA.forEach(a=> a.classList.toggle('active', a.dataset.nav===id));
      movePill();
    }
  });
}, { rootMargin:'-45% 0px -45% 0px' });
sectionIds.forEach(id=>{ const el = document.getElementById(id); if(el) io.observe(el); });

const navPill = document.getElementById('navPill');
function movePill(){
  const active = document.querySelector('#navLinks a.active');
  if(!active || !navPill) return;
  navPill.style.width = active.offsetWidth + 'px';
  navPill.style.transform = 'translateX(' + active.offsetLeft + 'px)';
  navPill.classList.add('active-pill');
}
window.addEventListener('resize', movePill);
navA.forEach(a=> a.addEventListener('mouseenter', ()=>{
  navPill.style.width = a.offsetWidth + 'px';
  navPill.style.transform = 'translateX(' + a.offsetLeft + 'px)';
  navPill.classList.add('active-pill');
}));
document.getElementById('navLinks').addEventListener('mouseleave', movePill);
setTimeout(movePill, 500);

const revealEls = document.querySelectorAll('.reveal, .reveal-left, .reveal-scale');
const revealIO = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); revealIO.unobserve(e.target); } });
}, { threshold:0.15 });
revealEls.forEach(el=> revealIO.observe(el));

const scrollProgress = document.getElementById('scrollProgress');
const toTopProgress = document.getElementById('toTopProgress');
const RING_CIRC = 132;
function updateProgress(){
  const h = document.documentElement;
  const scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
  scrollProgress.style.width = scrolled + '%';
  if(toTopProgress){ toTopProgress.style.strokeDashoffset = RING_CIRC - (RING_CIRC * scrolled/100); }
}
window.addEventListener('scroll', updateProgress, { passive:true });
updateProgress();

(function(){
  const visual = document.querySelector('.hero-visual');
  const hero = document.querySelector('.hero');
  const content = document.querySelector('.hero-content');
  if(!visual || !hero) return;
  let ticking = false;
  let pastHero = false;
  function onScroll(){
    if(ticking) return;
    ticking = true;
    requestAnimationFrame(()=>{
      const y = window.scrollY || window.pageYOffset;
      const heroH = hero.offsetHeight || 1;
      // Once fully scrolled past the hero, its parallax is invisible — commit
      // the final state once, then skip all further writes for the rest of the page.
      if(y > heroH){
        if(!pastHero){
          visual.style.setProperty('--scroll-prog', '1');
          visual.classList.add('parallax-1', 'scrolled-away');
          pastHero = true;
        }
        ticking = false;
        return;
      }
      pastHero = false;
      const prog = Math.min(1, Math.max(0, y / heroH));
      visual.style.setProperty('--scroll-y', y.toFixed(1));
      visual.style.setProperty('--scroll-prog', prog.toFixed(3));
      visual.classList.add('parallax-1');
      visual.classList.toggle('scrolled-away', prog > 0.55);
      if(content) content.style.transform = 'translateY(' + (-y * 0.06).toFixed(1) + 'px)';
      ticking = false;
    });
  }
  window.addEventListener('scroll', onScroll, { passive:true });
  onScroll();
})();

const cursorGlow = document.getElementById('cursorGlow');
let glowTimeout;
window.addEventListener('mousemove', (e)=>{
  cursorGlow.style.setProperty('--cx', e.clientX + 'px');
  cursorGlow.style.setProperty('--cy', e.clientY + 'px');
  cursorGlow.classList.add('active');
  clearTimeout(glowTimeout);
  glowTimeout = setTimeout(()=> cursorGlow.classList.remove('active'), 1400);
});

(function(){
  const headline = document.getElementById('heroHeadline');
  const grad = headline.querySelector('.grad');
  let wordCount = 0;
  if(grad){
    const text = grad.textContent;
    grad.textContent = '';
    const gw = document.createElement('span'); gw.className = 'rw';
    const gi = document.createElement('span'); gi.className = 'grad-word'; gi.textContent = text;
    gi.style.setProperty('--wi', wordCount++);
    gw.appendChild(gi); grad.appendChild(gw);
  }
  const walker = document.createTreeWalker(headline, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  let n; while(n = walker.nextNode()) textNodes.push(n);
  textNodes.forEach(node=>{
    if(node.parentElement && node.parentElement.closest('.grad')) return;
    const words = node.textContent.split(/(\s+)/);
    const frag = document.createDocumentFragment();
    words.forEach(w=>{
      if(w.trim()===''){ frag.appendChild(document.createTextNode(w)); return; }
      const wrap = document.createElement('span'); wrap.className = 'rw';
      const inner = document.createElement('span'); inner.textContent = w; inner.style.setProperty('--wi', wordCount++);
      wrap.appendChild(inner); frag.appendChild(wrap);
    });
    node.parentNode.replaceChild(frag, node);
  });
})();

(function(){
  const roles = ['Creative Designer','Video Editor','Marketing Specialist','Brand Strategist'];
  const el = document.getElementById('roleCycle');
  let idx = 0;
  function render(){
    const span = document.createElement('span');
    span.textContent = roles[idx];
    el.appendChild(span);
    requestAnimationFrame(()=> span.classList.add('active'));
    return span;
  }
  let current = render();
  setInterval(()=>{
    current.classList.remove('active'); current.classList.add('leave');
    idx = (idx+1) % roles.length;
    const next = render();
    setTimeout(()=>{ current.remove(); current = next; }, 520);
  }, 2600);
})();

(function(){
  const canvas = document.getElementById('particles');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = window.matchMedia('(hover:none), (pointer:coarse)').matches;
  if(reduceMotion || coarse || window.innerWidth < 700){ canvas.remove(); return; }
  const ctx = canvas.getContext('2d');
  let w,h,particles;
  const COLORS = ['59,130,246','139,92,246','34,211,238'];
  const mouse = { x:-9999, y:-9999, active:false };
  const LINK_DIST = 130;
  function resize(){
    w = canvas.width = canvas.offsetWidth * devicePixelRatio;
    h = canvas.height = canvas.offsetHeight * devicePixelRatio;
    canvas.style.width = canvas.offsetWidth+'px'; canvas.style.height = canvas.offsetHeight+'px';
  }
  function init(){
    resize();
    const count = Math.min(70, Math.floor((canvas.offsetWidth*canvas.offsetHeight)/16000));
    particles = Array.from({length:count},()=>({
      x:Math.random()*w, y:Math.random()*h, r:(Math.random()*1.6+0.7)*devicePixelRatio,
      vx:(Math.random()-0.5)*0.24*devicePixelRatio, vy:(Math.random()-0.5)*0.24*devicePixelRatio,
      c:COLORS[Math.floor(Math.random()*COLORS.length)], a:Math.random()*0.5+0.35, p:Math.random()*Math.PI*2
    }));
  }
  function tick(){
    ctx.clearRect(0,0,w,h);
    const mx = mouse.x*devicePixelRatio, my = mouse.y*devicePixelRatio;
    const linkDist = LINK_DIST*devicePixelRatio;
    for(let i=0;i<particles.length;i++){
      for(let j=i+1;j<particles.length;j++){
        const a=particles[i], b=particles[j];
        const dx=a.x-b.x, dy=a.y-b.y, dist=Math.sqrt(dx*dx+dy*dy);
        if(dist < linkDist){
          const op = (1 - dist/linkDist) * 0.18;
          ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y);
          ctx.strokeStyle = 'rgba(139,92,246,'+op.toFixed(3)+')'; ctx.lineWidth = devicePixelRatio*0.7;
          ctx.stroke();
        }
      }
      if(mouse.active){
        const a=particles[i];
        const dx=a.x-mx, dy=a.y-my, dist=Math.sqrt(dx*dx+dy*dy);
        if(dist < linkDist*1.3){
          const op = (1 - dist/(linkDist*1.3)) * 0.35;
          ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(mx,my);
          ctx.strokeStyle = 'rgba(59,130,246,'+op.toFixed(3)+')'; ctx.lineWidth = devicePixelRatio*0.8;
          ctx.stroke();
          const push = (1 - dist/(linkDist*1.3)) * 0.35;
          a.vx += (dx/(dist||1)) * push * 0.02;
          a.vy += (dy/(dist||1)) * push * 0.02;
        }
      }
    }
    particles.forEach(pt=>{
      pt.vx *= 0.985; pt.vy *= 0.985;
      pt.x+=pt.vx; pt.y+=pt.vy; pt.p+=0.02;
      if(pt.x<0) pt.x=w; if(pt.x>w) pt.x=0; if(pt.y<0) pt.y=h; if(pt.y>h) pt.y=0;
      const alpha = pt.a*(0.6+0.4*Math.sin(pt.p));
      ctx.beginPath(); ctx.arc(pt.x,pt.y,pt.r,0,Math.PI*2);
      ctx.fillStyle = 'rgba('+pt.c+','+alpha.toFixed(2)+')'; ctx.fill();
    });
    if(onScreen) requestAnimationFrame(tick);
  }
  // The hero canvas is only ever seen near the top of the page — once scrolled
  // past, stop running its per-frame O(n^2) link calculations entirely.
  let onScreen = true;
  new IntersectionObserver((entries)=>{
    const wasOnScreen = onScreen;
    onScreen = entries[0].isIntersecting;
    if(onScreen && !wasOnScreen) requestAnimationFrame(tick);
  }, { rootMargin: '150px 0px' }).observe(canvas);
  canvas.addEventListener('mousemove', (e)=>{
    const r = canvas.getBoundingClientRect();
    mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; mouse.active = true;
  });
  canvas.addEventListener('mouseleave', ()=> mouse.active = false);
  canvas.style.pointerEvents = 'auto';
  window.addEventListener('resize', resize);
  init(); tick();
})();

document.querySelectorAll('.btn').forEach(btn=>{
  btn.addEventListener('click', function(e){
    const r = this.getBoundingClientRect();
    const span = document.createElement('span');
    span.className = 'ripple-span';
    const size = Math.max(r.width,r.height);
    span.style.width = span.style.height = size+'px';
    span.style.left = (e.clientX-r.left-size/2)+'px';
    span.style.top = (e.clientY-r.top-size/2)+'px';
    this.style.position='relative'; this.style.overflow='hidden';
    this.appendChild(span);
    setTimeout(()=>span.remove(),650);
  });
});

(function(){
  const circle = document.getElementById('pfpCircle');
  const input = document.getElementById('pfpInput');
  const img = document.getElementById('pfpImg');
  circle.addEventListener('click', ()=> input.click());
  input.addEventListener('change', ()=>{
    const file = input.files[0]; if(!file) return;
    const reader = new FileReader();
    reader.onload = (e)=>{ img.src = e.target.result; circle.classList.add('has-img'); };
    reader.readAsDataURL(file);
  });
})();

(function(){
  const isFinePointer = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  if(!isFinePointer) return;
  document.documentElement.classList.add('custom-cursor');
  const dot = document.getElementById('cursorDot');
  const ring = document.getElementById('cursorRing');
  let mx=window.innerWidth/2, my=window.innerHeight/2, rx=mx, ry=my;
  let shown = false;
  window.addEventListener('mousemove', (e)=>{
    mx = e.clientX; my = e.clientY;
    dot.style.transform = 'translate('+mx+'px,'+my+'px) translate(-50%,-50%)';
    if(!shown){ shown = true; dot.classList.add('active'); ring.classList.add('active'); }
  });
  function tick(){
    rx += (mx-rx)*0.2; ry += (my-ry)*0.2;
    ring.style.transform = 'translate('+rx+'px,'+ry+'px) translate(-50%,-50%)';
    requestAnimationFrame(tick);
  }
  tick();
  document.addEventListener('mousedown', (e)=>{
    ring.classList.add('clicking');
    const fx = document.createElement('div');
    fx.className = 'cursor-click-fx';
    fx.style.left = e.clientX+'px';
    fx.style.top = e.clientY+'px';
    document.body.appendChild(fx);
    fx.addEventListener('animationend', ()=> fx.remove());
  });
  document.addEventListener('mouseup', ()=> ring.classList.remove('clicking'));
  const hoverables = 'a, button, .btn, .card, .pfp-circle, .skill-chip, input, textarea, .filter-btn';
  document.addEventListener('mouseover', (e)=>{
    if(e.target.closest(hoverables)){ ring.classList.add('hovering'); dot.classList.add('hovering'); }
  });
  document.addEventListener('mouseout', (e)=>{
    if(e.target.closest(hoverables)){ ring.classList.remove('hovering'); dot.classList.remove('hovering'); }
  });
  document.addEventListener('mouseleave', ()=>{ dot.classList.remove('active'); ring.classList.remove('active'); shown=false; });
})();
document.addEventListener('mousemove', (e)=>{
  const el = e.target.closest ? e.target.closest('.spot') : null;
  if(!el) return;
  const r = el.getBoundingClientRect();
  el.style.setProperty('--mx', (e.clientX - r.left) + 'px');
  el.style.setProperty('--my', (e.clientY - r.top) + 'px');
});

const SKILLS = [
  { cat:'Creative Design', icon:'fa-palette', items:[
    ['Brand Identity Design',95], ['Logo Design',92], ['Graphic Design',96], ['Social Media Design',94],
    ['Print & Marketing Materials',88], ['Business Card Design',90], ['Resume Design',85], ['Book Cover Design',87]
  ]},
  { cat:'Video Production', icon:'fa-clapperboard', items:[
    ['Video Editing',96], ['YouTube Video Editing',95], ['Visual Storytelling',93], ['Motion Graphics',90],
    ['Color Correction & Color Grading',89], ['Audio Editing & Enhancement',85],
    ['Short-Form Video Editing (Reels, Shorts & TikTok)',94], ['Video Post-Production',91]
  ]},
  { cat:'Digital Marketing', icon:'fa-chart-line', items:[
    ['Search Engine Optimization (SEO)',95], ['Social Media Management',94], ['Meta Ads (Facebook & Instagram Ads)',92],
    ['Google Ads (PPC)',91], ['Digital Marketing Strategy',90], ['Content Marketing',89],
    ['Keyword Research',88], ['Google Analytics (GA4)',87]
  ]}
];
const tabsEl = document.getElementById('skillsGrid');
function animateRing(el, target, duration){
  const start = performance.now();
  function step(now){
    const t = Math.min((now-start)/duration, 1);
    const eased = 1 - Math.pow(1-t, 3);
    el.style.setProperty('--pct', (eased*target).toFixed(1));
    if(t < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
SKILLS.forEach((s,ci)=>{
  const avg = Math.round(s.items.reduce((a,[,p])=>a+p,0) / s.items.length);
  const catClass = ci===0 ? 'c-design' : ci===1 ? 'c-video' : 'c-market';
  const catLabel = ci===0 ? 'Design' : ci===1 ? 'Video' : 'Marketing';
  const chipIcons = ci===0 ? ['fa-pen-nib','fa-shapes','fa-palette','fa-icons','fa-print','fa-id-card-clip','fa-file-lines','fa-book'] :
                    ci===1 ? ['fa-scissors','fa-youtube','fa-film','fa-wand-magic-sparkles','fa-droplet','fa-music','fa-mobile-screen','fa-clapperboard'] :
                    ['fa-magnifying-glass-chart','fa-share-nodes','fa-bullseye','fa-ad','fa-compass-drafting','fa-newspaper','fa-key','fa-chart-pie'];
  const card = document.createElement('div');
  card.className = 'card skill-card glow-border tilt spot reveal-scale';
  card.style.setProperty('--i', ci);
  const catKey = ci===0 ? 'design' : ci===1 ? 'video' : 'market';
  card.dataset.cat = catKey;
  const ringCls = ci===0 ? 'r-design' : ci===1 ? 'r-video' : 'r-market';
  const barClr = ci===0 ? 'linear-gradient(90deg,rgba(59,130,246,0.6),rgba(139,92,246,0.6))' : ci===1 ? 'linear-gradient(90deg,rgba(139,92,246,0.6),rgba(168,85,247,0.6))' : 'linear-gradient(90deg,rgba(34,211,238,0.6),rgba(59,130,246,0.6))';
  const icCls = ci===0 ? 'ib-design' : ci===1 ? 'ib-video' : 'ib-market';
  card.innerHTML = `
    <div class="spot-glow"></div><div class="sheen"></div>
    <div class="skill-card-head">
      <div class="skill-ring ${ringCls}" data-target="${avg}"><span>${avg}%</span></div>
      <div class="ttl">
        <div class="ic-badge ${icCls}"><i class="fa-solid ${s.icon}"></i></div>
        <div class="skill-cat-title">${s.cat}</div>
        <div class="skill-cat-sub">${s.items.length} core skills</div>
      </div>
    </div>
    <div class="skill-chip-list">
      ${s.items.map(([name,pct],si)=>`
        <div class="skill-chip">
          <div class="chip-icon ${catClass}"><i class="fa-solid ${chipIcons[si] || 'fa-circle'}"></i></div>
          <div class="chip-body">
            <span class="chip-name">${name}</span>
            <div class="chip-bar"><div class="chip-bar-fill" data-pct="${pct}" style="--bar-clr:${barClr}"></div></div>
          </div>
          <span class="pct">${pct}%</span>
        </div>`).join('')}
    </div>
    <div class="skill-card-footer">
      <span class="scf-label">Average proficiency</span>
      <span class="scf-badge">${avg}%</span>
    </div>`;
  tabsEl.appendChild(card);
  revealIO.observe(card);
});
const skillRingIO = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      e.target.querySelectorAll('.skill-ring').forEach((ring,i)=>{
        setTimeout(()=> animateRing(ring, +ring.dataset.target, 1100), i*40);
      });
      e.target.querySelectorAll('.chip-bar-fill').forEach((bar,i)=>{
        setTimeout(()=> bar.style.transform = 'scaleX(' + (+bar.dataset.pct / 100) + ')', 200 + i*60);
      });
      skillRingIO.unobserve(e.target);
    }
  });
},{threshold:0.15, rootMargin:'50px'});
document.querySelectorAll('.skill-card').forEach(c=> skillRingIO.observe(c));
setTimeout(()=> document.querySelectorAll('.skill-card').forEach(c=>{
  if(c.querySelector('.skill-ring') && c.querySelector('.skill-ring').style.getPropertyValue('--pct') === '0'){
    c.querySelectorAll('.skill-ring').forEach((ring,i)=>{
      setTimeout(()=> animateRing(ring, +ring.dataset.target, 1100), i*40);
    });
    c.querySelectorAll('.chip-bar-fill').forEach((bar,i)=>{
      setTimeout(()=> bar.style.transform = 'scaleX(' + (+bar.dataset.pct / 100) + ')', 200 + i*60);
    });
  }
}), 2500);

const SERVICES = [
  { icon:'fa-swatchbook', title:'Brand Identity Design', cat:'Design', catCls:'svcat-design', icCls:'sv-ic-magenta', desc:'Logos and complete visual identity systems that give your brand a distinct, memorable presence.', tags:['Logo','Brand Guide','Visual Identity'],
    detail:'I build identities from the ground up — researching your market and audience, defining a clear brand voice, and designing a flexible system that stays recognizable across every touchpoint, from your logo to your social feed.',
    points:['Logo suites — primary, secondary & monogram','Brand colour systems & typography pairing','Full brand guidelines & usage rules','Business card & stationery design','Brand voice & messaging notes'],
    process:['Discovery — goals, audience & competitor research','Design — logo suite, colour, type & system','Handoff — a usable brand book your team can apply'],
    outcome:'A confident, cohesive identity that makes you look established from day one.', who:'Startups, founders and small businesses building a brand from scratch or refreshing a tired, inconsistent identity.', page:{ overview:'A strong brand identity is the foundation of how customers recognise and trust your business. I design complete visual identity systems from logo suites and colour palettes to typography and brand guidelines, so your brand looks consistent and professional across every platform, from your website and social media to packaging and print.', included:['Primary, secondary and monogram logo suites','Brand colour system with hex, RGB and CMYK values','Typography pairing and font guidelines','Full brand guidelines and usage rules','Business card, letterhead and stationery design','Brand voice and messaging notes','Logo animation and motion variants','Organised brand asset kit with source files'], process:['Discovery — understand your goals, audience and competitors','Design — build the logo suite, colour, type and full system','Handoff — deliver a usable brand book your team can apply'], benefits:['Instant brand recognition and trust','A consistent look across every channel','Assets your team can reuse without guesswork','A premium, established appearance from day one','A scalable identity that grows with your business','Stronger customer trust and recall'] } },
  { icon:'fa-images', title:'Graphic & Social Media Design', cat:'Design', catCls:'svcat-design', icCls:'sv-ic-indigo', desc:'Scroll-stopping social creatives and graphic design that keep your brand consistent everywhere.', tags:['Social Media','Posters','Banners'],
    detail:'From daily social posts to full campaign visuals, every asset is built on a consistent template system so your brand looks unified at any size — and your feed feels intentional instead of random.',
    points:['Scroll-stopping social creatives','Posters, banners & ad visuals','Carousel & story templates','Unified visual systems across platforms','Highlight & story covers'],
    process:['Audit your visuals & define a signature look','Build reusable templates & asset kits','Roll out across platforms with a content rhythm'],
    outcome:'A feed that stops the scroll, plus a toolkit your team can reuse.', who:'Creators, coaches and brands that need a consistent, scroll-stopping social media presence across Instagram, Facebook and LinkedIn.', page:{ overview:'Social media is where most customers meet your brand first, so your visuals need to stop the scroll and stay on-brand. I create scroll-stopping social media graphics, ad creatives and reusable template systems that keep your feed consistent and intentional across Instagram, Facebook, LinkedIn and beyond.', included:['Social media posts, stories and covers','Ad creatives for Meta and Google','Posters, banners and flyer design','Carousel and story templates','Highlight and story covers','Unified visual systems across platforms','Email and newsletter graphics','Branded template kits for your team'], process:['Audit your current visuals and define a signature look','Build reusable templates and asset kits','Roll out across platforms with a steady content rhythm'], benefits:['Higher engagement on social posts','A feed that looks intentional and premium','Reusable templates that save time','Consistent branding at every size','More saves, shares and profile visits','On-brand visuals without hiring help'] } },
  { icon:'fa-print', title:'Print & Marketing Materials', cat:'Design', catCls:'svcat-design', icCls:'sv-ic-pink', desc:'Business cards, resumes and book covers designed with the same care as any flagship brand asset.', tags:['Business Card','Resume','Book Cover'],
    detail:'Print gets the same precision as digital — correct colour profiles, safe margins and press-ready files, so what you approve is exactly what gets printed.',
    points:['Business cards, resumes & letterheads','Book covers & brochures','Flyers & print-ready artwork','CMYK & bleed-checked final files','Menu, brochure & packaging layout'],
    process:['Brief & specs — size, stock, finish','Design with print-safe margins & CMYK','Press-ready handoff with bleed & crop marks'],
    outcome:'Print-ready files that print perfectly the first time.', who:'Authors, businesses and agencies needing flawless, press-ready print and marketing collateral — from business cards to book covers.', page:{ overview:'Print still matters for first impressions, from business cards at a meeting to book covers on a shelf. I design print and marketing materials with the same precision as digital, using correct colour profiles, safe margins and press-ready files, so what you approve is exactly what gets printed.', included:['Business cards, resumes and letterheads','Book covers and brochure layout','Flyers and print-ready artwork','CMYK and bleed-checked final files','Menu, brochure and packaging layout','Trade show and signage graphics','Editable source files and print specs','Large-format and signage graphics'], process:['Brief and specs — size, stock and finish','Design with print-safe margins and CMYK','Press-ready handoff with bleed and crop marks'], benefits:['Files that print perfectly the first time','A polished, professional first impression','Correct colours across digital and print','Ready-to-send artwork for any printer','Fewer reprints and costly mistakes','Brand consistency from screen to print'] } },
  { icon:'fa-pen-nib', title:'Thumbnail & Book Cover Design', cat:'Design', catCls:'svcat-design', icCls:'sv-ic-purple', desc:'Click-worthy YouTube thumbnails and professional book covers designed to stand out in crowded feeds.', tags:['Thumbnail','Book Cover','Poster'],
    detail:'First impressions happen in a split second. I design YouTube thumbnails that earn clicks and book covers that sell — bold typography, punchy visuals and composition built for tiny mobile screens.',
    points:['YouTube thumbnail design','Book cover front & full wrap','Kindle Direct Publishing ready files','Poster & flyer design','Social media ad creatives'],
    process:['Brief — brand, audience & platform specs','Design — bold composition & readable type','Handoff — JPG, PNG & print-ready files'],
    outcome:'Visuals that stop the scroll and earn the click.', who:'Creators, authors and businesses that need standout YouTube thumbnails, book covers and promotional graphics.', page:{ overview:'Your thumbnail or book cover is often the first thing people see — it needs to earn that split-second decision to click or pick up. I design YouTube thumbnails optimised for mobile feeds and book covers that look professional at thumbnail size, using bold typography, punchy visuals and tested composition.', included:['YouTube thumbnail design (custom per video)','Book cover front, spine and full wrap','Kindle Direct Publishing (KDP) ready files','Poster and flyer design','Social media ad creatives','E-book and print cover versions','Source files for future edits','A/B tested thumbnail variants'], process:['Brief — understand your brand, audience and platform specs','Design — bold composition and readable type','Handoff — deliver JPG, PNG and print-ready files'], benefits:['Higher click-through rates on YouTube','Book covers that sell at first glance','Optimised for mobile and thumbnail sizes','Print-ready files with correct specs','A consistent visual style across platforms','Faster turnaround with template-based workflow'] } },
  { icon:'fa-film', title:'Video Editing & YouTube Production', cat:'Video', catCls:'svcat-video', icCls:'sv-ic-purple', desc:'Polished video editing and YouTube-ready production that keeps viewers watching till the end.', tags:['YouTube','Reels','Shorts'],
    detail:'Edits built around retention — a strong hook in the first three seconds, clean pacing, and platform-native cuts for YouTube, Reels and Shorts, finished with sound design and captions.',
    points:['Long-form & YouTube edits','Reels, Shorts & TikTok cuts','Retention-focused pacing & hooks','Sound design, captions & thumbnails','YouTube SEO & end-screen strategy'],
    process:['Hook-first structure & rough cut','Polish — pacing, colour, sound & captions','Platform cuts for Shorts, Reels & TikTok'],
    outcome:'Videos people actually finish — and that perform.', who:'YouTubers, creators and businesses that want polished, retention-first video content for YouTube, Reels, Shorts and TikTok.', page:{ overview:'Video is the fastest way to grow an audience, but retention is everything. I edit long-form YouTube videos, shorts, reels and TikToks with strong hooks, clean pacing and platform-native cuts, finished with sound design, captions and thumbnails that earn the click.', included:['Long-form and YouTube video edits','Reels, Shorts and TikTok cuts','Retention-focused pacing and hooks','Sound design, captions and subtitles','Thumbnail and end-screen strategy','Podcast and corporate video editing','YouTube SEO titles, tags and descriptions','Chapter markers and cards'], process:['Hook-first structure and rough cut','Polish — pacing, colour, sound and captions','Platform cuts for Shorts, Reels and TikTok'], benefits:['Videos people actually finish watching','Higher watch time and retention','Platform-ready formats that perform','A consistent, on-brand video presence','Better search visibility on YouTube','A reliable, repeatable video workflow'] } },
  { icon:'fa-wand-magic-sparkles', title:'Motion Graphics & Color Grading', cat:'Video', catCls:'svcat-video', icCls:'sv-ic-cyan', desc:'Motion graphics, color correction and color grading that give your footage a cinematic finish.', tags:['Motion FX','Color','VFX'],
    detail:'Add movement and mood to your footage — animated brand moments, kinetic typography and a cinematic grade that ties the whole piece together and elevates raw clips.',
    points:['Logo & intro animations','Kinetic typography & titles','Cinematic color correction','VFX & visual polish','Lower-thirds & animated logos'],
    process:['Concept & style frames','Animation & compositing','Cinematic colour grade & finishing'],
    outcome:'Footage that looks premium and unmistakably on-brand.', who:'Brands and creators who want cinematic motion graphics, animated logos and colour-graded video that feels premium.', page:{ overview:'Motion and colour are what turn raw footage into something that feels premium. I create animated brand moments, kinetic typography and cinematic colour grades that add energy and mood, tying your whole video together and making it unmistakably on-brand.', included:['Logo and intro animations','Kinetic typography and title sequences','Cinematic colour correction and grading','VFX and visual polish','Lower-thirds and animated logos','Explainer and promo motion graphics','Logo stings and branded intros','Social motion ads and GIFs'], process:['Concept and style frames','Animation and compositing','Cinematic colour grade and finishing'], benefits:['A premium, cinematic look','Animated assets that build recognition','More engaging, energetic videos','Footage that feels polished and on-brand','Higher engagement on motion posts','A signature animated brand style'] } },
  { icon:'fa-microphone', title:'Podcast & Corporate Video', cat:'Video', catCls:'svcat-video', icCls:'sv-ic-blue', desc:'Professional podcast editing and corporate video production with clean audio, precise pacing and on-brand polish.', tags:['Podcast','Corporate','Audio'],
    detail:'Clean audio, tight pacing, and a polished finish that sounds and looks professional. I edit podcast episodes, corporate videos, talking-head content and event recaps with multi-cam sync, audio levelling and colour consistency.',
    points:['Podcast audio & video editing','Multi-cam sync & switching','Corporate interview & event videos','Audio levelling & noise removal','Captions, chapters & show notes'],
    process:['Review raw footage & select best takes','Edit — pacing, audio sync & colour grade','Polish — captions, chapters & export'],
    outcome:'Professional podcast and corporate content that builds credibility.', who:'Podcasters, businesses and agencies needing clean, professional video and audio editing for interviews, corporate messaging and long-form content.', page:{ overview:'Podcasts and corporate videos build trust through consistency — clean audio, tight pacing and a polished finish that sounds and looks professional. I edit podcast episodes, corporate interviews, talking-head content and event recaps with multi-cam sync, audio levelling, colour consistency and polished captions.', included:['Podcast audio and video editing','Multi-cam sync and camera switching','Corporate interview and event videos','Audio levelling, noise removal and cleanup','Captions, chapters and show notes','Intro, outro and transition graphics','Colour grading for consistent look','Export for YouTube, podcast platforms or internal use'], process:['Review raw footage and select the best takes','Edit — pacing, audio sync and colour grade','Polish — captions, chapters and export for each platform'], benefits:['Professional sound and visual quality','Faster turnaround with structured workflow','Consistent audio levels across episodes','Clean, on-brand corporate messaging','Multi-platform export ready to publish','Builds credibility and audience trust'] } },
  { icon:'fa-magnifying-glass-chart', title:'SEO (Audit, Keywords & Technical)', cat:'Marketing', catCls:'svcat-marketing', icCls:'sv-ic-cyan', desc:'Full SEO audits, keyword research, on-page and technical SEO to help you rank and get found.', tags:['Audit','Keywords','On-Page'],
    detail:'A clear, actionable SEO plan — I find what your audience actually searches for, fix the technical issues holding your rankings back, and set up tracking so you can prove it is working.',
    points:['Technical & on-page SEO audits','Keyword & competitor research','Google Search Console setup','Ranking & organic traffic growth','Internal linking & site structure'],
    process:['Audit — technical, on-page & backlinks','Research — keywords & search intent','Implement & grow with ongoing tracking'],
    outcome:'Higher rankings and steady, compounding organic traffic.', who:'Businesses that want to rank on Google and win consistent, free organic traffic through technical and on-page SEO.', page:{ overview:'Good SEO is how customers find you on Google without paying for every click. I run full SEO audits, deep keyword research and technical optimisation, fixing the issues that hold your rankings back and building a strategy that grows steady, compounding organic traffic.', included:['Technical and on-page SEO audits','Keyword and competitor research','Google Search Console and analytics setup','Internal linking and site structure','Local SEO and schema markup','Ranking and organic traffic reporting','Core Web Vitals and page-speed optimisation','Monthly SEO reporting and roadmap'], process:['Audit — technical, on-page and backlink review','Research — keywords and search intent','Implement and grow with ongoing tracking'], benefits:['Higher Google rankings for target keywords','Steady, compounding organic traffic','More qualified visitors from search','A clear, measurable SEO roadmap','Lower customer-acquisition cost over time','Topical authority in your niche'] } },
  { icon:'fa-bullhorn', title:'Digital Marketing & Social Media', cat:'Marketing', catCls:'svcat-marketing', icCls:'sv-ic-blue', desc:'Data-informed marketing strategy and social media marketing built around real business goals.', tags:['Strategy','Meta Ads','Analytics'],
    detail:'Campaigns tied to real outcomes — from ad creative to reporting, every decision is backed by the numbers that matter to your business, not vanity metrics.',
    points:['Meta & Google ad campaigns','Content & social strategy','Analytics, reporting & insights','Conversion-focused funnels','A/B testing & creative iteration'],
    process:['Strategy & precise audience targeting','Creative, launch & continuous testing','Measure, report & optimise'],
    outcome:'Campaigns that spend smart and actually convert.', who:'Brands ready to run paid ads and grow qualified leads with data-driven Meta and Google marketing.', page:{ overview:'Effective marketing is about outcomes, not vanity metrics. I plan and run data-informed campaigns from Meta and Google ads to organic social strategy, backed by analytics and continuous testing, so every decision moves your real business goals forward.', included:['Meta and Google ad campaign management','Content and social media strategy','Analytics, reporting and insights','Conversion-focused funnel building','A/B testing and creative iteration','Audience targeting and retargeting','Landing page and ad-creative testing','Monthly performance dashboards'], process:['Strategy and precise audience targeting','Creative, launch and continuous testing','Measure, report and optimise'], benefits:['Ad spend that works harder','Campaigns tied to real results','Clear reporting you can trust','Steady growth in leads and sales','Better return on ad spend (ROAS)','Predictable, scalable lead generation'] } },
  { icon:'fa-file-lines', title:'Content Marketing & Competitor Analysis', cat:'Marketing', catCls:'svcat-marketing', icCls:'sv-ic-pink', desc:'Content strategy and competitor analysis that uncover opportunities your brand can own.', tags:['Content','Research','Strategy'],
    detail:'I map the gap between you and your competitors, then build a content plan that claims the topics they are missing — so you own the conversation in your niche.',
    points:['Content strategy & calendars','Competitor gap analysis','Blog & email content','Performance review & iteration','Repurposing & distribution plan'],
    process:['Competitor & content gap analysis','Content strategy & calendar','Create, publish & iterate on the data'],
    outcome:'A content engine that builds lasting authority.', who:'Founders and marketers who want to own their niche with strategic, SEO-driven content and competitor analysis.', page:{ overview:'Content is how brands build authority over time, but only if it targets the right gaps. I map the space between you and your competitors, then build a content strategy and calendar that claims the topics they are missing, so you own the conversation in your niche.', included:['Content strategy and editorial calendars','Competitor and content gap analysis','Blog, email and social content','Repurposing and distribution planning','Performance review and iteration','Thought-leadership positioning','SEO blog writing and optimisation','Newsletter and email sequences'], process:['Competitor and content gap analysis','Content strategy and calendar','Create, publish and iterate on the data'], benefits:['Authority that compounds over time','Content that targets real demand','A repeatable content engine','A clearer edge over competitors','Evergreen traffic that keeps growing','A clear edge over competing brands'] } }
];
const svColors = ['sv-ic-blue','sv-ic-purple','sv-ic-pink','sv-ic-purple','sv-ic-cyan','sv-ic-cyan','sv-ic-blue','sv-ic-pink'];
const servicesGrid = document.getElementById('servicesGrid');
SERVICES.forEach((s,idx)=>{
  const num = String(idx+1).padStart(2,'0');
  const tagsHtml = s.tags.map(t => '<span class="sv-tag">'+t+'</span>').join('');
  const card = document.createElement('div');
  card.className = 'card service-card glow-border tilt spot reveal-scale';
  card.style.setProperty('--i', idx);
  card.innerHTML = `<div class="spot-glow"></div><div class="sheen"></div><div class="sv-idx">${num}</div><div class="ic ${s.icCls}"><i class="fa-solid ${s.icon}"></i></div><div class="sv-cat ${s.catCls}">${s.cat}</div><h3>${s.title}</h3><p>${s.desc}</p><div class="sv-tags">${tagsHtml}</div><button type="button" class="learn service-learn" data-service="${s.title}">Learn More <i class="fa-solid fa-arrow-right"></i></button>`;
  card.addEventListener('click', ()=> openService(idx));
  card.querySelector('.service-learn').addEventListener('click', (e)=>{ e.stopPropagation(); openService(idx); });
  servicesGrid.appendChild(card);
  revealIO.observe(card);
});

const sd = document.getElementById('serviceDetail');
if (sd.parentElement !== document.documentElement) document.documentElement.appendChild(sd);
const sdPanel = sd.querySelector('.sd-panel');
const sdContent = document.getElementById('sdContent');
const sdBack = document.getElementById('sdBack');
const sdClose = document.getElementById('sdClose');
let sdLastFocus = null;
function openService(idx){
  const s = SERVICES[idx]; const pg = s.page || {};
  const included = (pg.included||[]).map(it => '<li><i class="fa-solid fa-circle-check"></i><span>'+it+'</span></li>').join('');
  const steps = (pg.process||[]).map(p => '<li>'+p+'</li>').join('');
  const benefits = (pg.benefits||[]).map(b => '<li><i class="fa-solid fa-star"></i><span>'+b+'</span></li>').join('');
  const who = s.who || '';
  sdContent.innerHTML = '<div class="sd-head"><div class="sd-ico '+s.icCls+'"><i class="fa-solid '+s.icon+'"></i></div><div class="sd-head-text"><div class="sd-cat '+s.catCls+'">'+s.cat+'</div><h2 class="sd-title">'+s.title+'</h2><p class="sd-overview">'+ (pg.overview||'') +'</p></div></div>'
    + (who ? '<div class="sd-perfect"><div><div class="sp-label">Perfect for</div><div class="sp-text">'+who+'</div></div></div>' : '')
    + '<div class="sd-grid">'
    + '<section class="sd-section sd-sec-included"><h3>What is included</h3><ul class="sd-list">'+included+'</ul></section>'
    + '<section class="sd-section sd-sec-steps"><h3>How I work</h3><ol class="sd-steps">'+steps+'</ol></section>'
    + '<section class="sd-section sd-sec-benefits"><h3>Benefits you get</h3><ul class="sd-list sd-benefits">'+benefits+'</ul></section>'
    + '</div>'
    + '<div class="sd-cta"><button type="button" class="btn primary" id="sdSend"><i class="fa-solid fa-paper-plane"></i> Send Message</button><a class="btn ghost" href="mailto:hello.rafidzaman@gmail.com?subject='+encodeURIComponent(s.title)+'"><i class="fa-solid fa-envelope"></i> Email me</a></div>';
  sdContent.querySelector('#sdSend').addEventListener('click', ()=>{
    closeService();
    const subj = document.getElementById('fSubject');
    if(subj){ subj.value = s.title; subj.dispatchEvent(new Event('input')); }
    const contact = document.getElementById('contact');
    const navH = (document.getElementById('navbar') || { offsetHeight: 0 }).offsetHeight;
    const y = Math.max(0, window.scrollY + contact.getBoundingClientRect().top - navH - 14);
    if(window.__fxScrollTo){ window.__fxScrollTo(y); }
    else { window.scrollTo({ top: y, behavior: (window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth') }); }
    setTimeout(()=>{ const el = document.getElementById('fName'); if(el) el.focus({preventScroll:true}); }, 700);
  });
  sdLastFocus = document.activeElement;
  sd.classList.add('open'); sd.setAttribute('aria-hidden','false');
  sdPanel.scrollTop = 0; document.body.classList.add('sd-lock'); document.documentElement.classList.add('sd-lock');
  sdBack.focus();
}
function closeService(){
  sd.classList.remove('open'); sd.setAttribute('aria-hidden','true');
  document.body.classList.remove('sd-lock'); document.documentElement.classList.remove('sd-lock');
  if(sdLastFocus && sdLastFocus.focus) sdLastFocus.focus();
}
sdBack.addEventListener('click', closeService);
if (sdClose) sdClose.addEventListener('click', closeService);
document.addEventListener('keydown', (e)=>{ if(e.key==='Escape' && sd.classList.contains('open')) closeService(); });

const CATEGORIES = [
  { key:'branding', emoji:'🎨', icon:'fa-swatchbook', title:'Branding',
    desc:'A brand that looks like it belongs in the room before it even speaks — logo suites, colour systems, typography pairing and a guideline book detailed enough for any vendor to get it right, every time.',
    items:['Logo Design','Brand Identity','Business Card Design','Stationery Design','Brand Guidelines'] },
  { key:'graphic', emoji:'🖌️', icon:'fa-images', title:'Graphic Design',
    desc:'Design that earns the scroll and the share — social posts, YouTube thumbnails, book covers, flyers and brochures, all built on one template system so a feed or a folder never looks thrown together.',
    items:['Social Media Design','Book Cover Design','Thumbnail Design','Flyer Design','Brochure Design','Banner Design','Resume Design','Poster Design','Print Design'] },
  { key:'video', emoji:'🎬', icon:'fa-clapperboard', title:'Video Editing',
    desc:'Cuts that fight for every second of attention — hook-first pacing, tight edits and sound design across long-form YouTube, Shorts, Reels, podcasts and corporate video, built to hold a viewer to the very last frame.',
    items:['YouTube Editing','Long-form Editing','Shorts Editing','Reels Editing','Podcast Editing','Corporate Videos','Color Grading','Audio Enhancement'] },
  { key:'motion', emoji:'✨', icon:'fa-wand-magic-sparkles', title:'Motion Graphics',
    desc:'The finishing touch that turns raw footage into something worth rewatching — logo reveals, intros, outros, kinetic typography and explainer motion engineered to feel premium in three seconds flat.',
    items:['Logo Animation','Intro Animation','Outro Animation','Lower Thirds','Kinetic Typography','Motion Titles','Animated Social Media Graphics'] },
  { key:'seo', emoji:'📈', icon:'fa-magnifying-glass-chart', title:'SEO',
    desc:'Rankings built on evidence, not guesswork — full technical and on-page audits, keyword and competitor research, and a Search Console setup that turns invisible pages into pages people actually find.',
    items:['SEO Audit','Keyword Research','On-Page SEO','Technical SEO','Google Search Console','Google Analytics','Ranking Improvements'] },
  { key:'marketing', emoji:'🚀', icon:'fa-bullhorn', title:'Digital Marketing',
    desc:'Every bit of ad spend tracked back to a real result — Google and Meta campaigns, content strategy and reporting built around one question: what is the budget actually earning back.',
    items:['Google Ads','Meta Ads','Social Media Marketing','Content Marketing','Email Marketing','Analytics & Reporting','Campaign Performance'] }
];

/* =====================================================================
   PORTFOLIO LINKS — paste your real work links here.
   Clicking a portfolio card opens the matching link in a new tab.

   • Whole category .... use the category key:  'branding': 'https://...'
   • A single service ... use  key:index  (index starts at 0):
                                'branding:0': 'https://...'  // Logo Design
                                'video:2':    'https://...'  // Shorts Editing

   A more specific "key:index" link always wins over the category link.
   Leave a value as '' (or remove the line) and that card falls back to
   the built-in image preview instead of opening a link.

   Category keys: branding · graphic · video · motion · seo · marketing
   ===================================================================== */
const PORTFOLIO_LINKS = {
  branding:  '',   // e.g. 'https://www.behance.net/yourname'
  graphic:   '',
  video:     '',   // e.g. 'https://www.youtube.com/@yourchannel'
  motion:    '',
  seo:       '',
  marketing: ''
  // Per-service overrides (optional), e.g.:
  // 'graphic:2': 'https://drive.google.com/your-thumbnails-folder',
};

/* Resolve the best link for a portfolio card: item-specific first, then category. */
function getPortfolioLink(catKey, idx){
  return PORTFOLIO_LINKS[catKey + ':' + idx] || PORTFOLIO_LINKS[catKey] || '';
}

const catGrid = document.getElementById('catGrid');
const catStage = document.getElementById('pfCategoryStage');
const detailStage = document.getElementById('pfDetailStage');
const subGrid = document.getElementById('subGrid');
const pfDetailEmoji = document.getElementById('pfDetailEmoji');
const pfDetailTitle = document.getElementById('pfDetailTitle');
const pfDetailCount = document.getElementById('pfDetailCount');
const pfDetailDesc = document.getElementById('pfDetailDesc');
const pfBackBtn = document.getElementById('pfBackBtn');
const pfStatsRow = document.getElementById('pfStatsRow');
const pfDetailProgressFill = document.getElementById('pfDetailProgressFill');
const pfDetailProgressTxt = document.getElementById('pfDetailProgressTxt');

let currentCatIdx = 0;
const subImages = {};

(function renderPfStats(){
  const totalServices = CATEGORIES.reduce((sum,c)=> sum + c.items.length, 0);
  const stats = [
    { ic:'fa-layer-group', num: CATEGORIES.length, lbl:'Categories' },
    { ic:'fa-briefcase', num: totalServices, lbl:'Total Services' },
    { ic:'fa-swatchbook', num: 120, lbl:'Projects Delivered' },
    { ic:'fa-circle-check', num:'Open', lbl:'Availability' }
  ];
  stats.forEach((s,i)=>{
    const pill = document.createElement('div');
    pill.className = 'pf-stat-pill spot reveal-scale';
    pill.style.setProperty('--i', i);
    pill.innerHTML = `<div class="spot-glow"></div><div class="psp-ic"><i class="fa-solid ${s.ic}"></i></div>
      <div><div class="psp-num">${s.num}</div><div class="psp-lbl">${s.lbl}</div></div>`;
    pfStatsRow.appendChild(pill);
    revealIO.observe(pill);
  });
})();

CATEGORIES.forEach((cat, idx)=>{
  const tagPills = cat.items.slice(0,3).map(n=>`<span>${n}</span>`).join('');
  const card = document.createElement('div');
  card.className = 'cat-card spot reveal-scale';
  card.style.setProperty('--i', idx);
  card.dataset.cat = cat.key;
  card.innerHTML = `
    <div class="spot-glow"></div>
    <div class="cat-index-num">0${idx+1}</div>
    <div class="cat-top">
      <div class="cat-emoji-badge"><span class="cat-emoji-glyph">${cat.emoji}</span></div>
      <div class="cat-count-pill"><i class="fa-solid fa-layer-group" style="font-size:9px;margin-right:4px;"></i>${cat.items.length} services</div>
    </div>
    <h3>${cat.title}</h3>
    <div class="cat-sub-preview">${cat.desc}</div>
    <div class="cat-tag-row">${tagPills}${cat.items.length>3 ? '<span>+'+(cat.items.length-3)+' more</span>' : ''}</div>
    <div class="cat-explore">View Project <i class="fa-solid fa-arrow-right"></i></div>
    <div class="cat-progress-row"><span></span><span></span><span></span><span></span><span></span></div>`;
  card.addEventListener('click', ()=> openCategory(idx));
  catGrid.appendChild(card);
  revealIO.observe(card);
});

function renderSubGrid(catIdx){
  const cat = CATEGORIES[catIdx];
  subGrid.innerHTML = '';
  cat.items.forEach((name, i)=>{
    const key = cat.key+':'+i;
    const imgs = subImages[key];
    const firstImg = Array.isArray(imgs) ? imgs[0] : (imgs || '');
    const hasLink = !!getPortfolioLink(cat.key, i);
    const card = document.createElement('div');
    card.className = 'sub-card spot reveal-scale' + (hasLink ? ' has-link' : '');
    card.style.setProperty('--i', i);
    card.innerHTML = `
      <div class="spot-glow"></div><div class="sheen"></div>
      <div class="sub-thumb${firstImg ? ' has-img':''}" data-key="${key}">
        <div class="sub-cat-chip"><i class="fa-solid ${cat.icon}"></i></div>
        ${hasLink ? '' : `<button type="button" class="sub-upload-btn" data-key="${key}" title="Upload your image" aria-label="Upload image"><i class="fa-solid fa-camera"></i></button>`}
        <img alt="${name}" loading="lazy" decoding="async" ${firstImg ? 'src="'+firstImg+'"':''}>
        <div class="sub-thumb-scrim"></div>
        <div class="sph"><i class="fa-solid ${hasLink ? 'fa-arrow-up-right-from-square' : cat.icon}"></i><span>${hasLink ? 'View work' : 'Click camera to<br>add your image'}</span></div>
      </div>
      <div class="sub-body">
        <span class="sname">${name}</span>
        <i class="fa-solid fa-arrow-up-right-from-square sarrow"></i>
      </div>`;
    subGrid.appendChild(card);
    revealIO.observe(card);
  });
}

function openCategory(catIdx){
  currentCatIdx = catIdx;
  const cat = CATEGORIES[catIdx];
  detailStage.dataset.cat = cat.key;
  pfDetailEmoji.textContent = cat.emoji;
  pfDetailTitle.textContent = cat.title;
  pfDetailCount.textContent = cat.items.length + ' services in this category';
  pfDetailDesc.textContent = cat.desc;
  renderSubGrid(catIdx);

  const pct = Math.round(((catIdx+1)/CATEGORIES.length)*100);
  pfDetailProgressTxt.textContent = (catIdx+1)+' of '+CATEGORIES.length+' categories';
  pfDetailProgressFill.style.transform = 'scaleX(0)';
  requestAnimationFrame(()=>{ pfDetailProgressFill.style.transform = 'scaleX('+(pct/100)+')'; });

  catStage.classList.add('leaving');
  setTimeout(()=>{
    catStage.classList.add('hidden');
    catStage.classList.remove('leaving');
    detailStage.classList.remove('hidden');
    requestAnimationFrame(()=> detailStage.classList.remove('leaving'));
    document.getElementById('portfolio').scrollIntoView({ behavior:'smooth', block:'start' });
  }, 320);
  updateURL(cat.key);
}
function closeCategory(){
  detailStage.classList.add('leaving');
  const floatBtn = document.getElementById('pfFloatBack');
  if(floatBtn) floatBtn.classList.remove('show');
  setTimeout(()=>{
    detailStage.classList.add('hidden');
    detailStage.classList.remove('leaving');
    catStage.classList.remove('hidden');
  }, 320);
  updateURL();
}
pfBackBtn.addEventListener('click', closeCategory);
document.addEventListener('keydown', (e)=>{
  const lb = document.getElementById('lightbox');
  if(e.key === 'Escape' && !detailStage.classList.contains('hidden') && !(lb && lb.classList.contains('open'))){
    closeCategory();
  }
});
const pfFloatBack = document.getElementById('pfFloatBack');
const pfDetailHead = document.querySelector('.pf-detail-head');
function updatePfFloatBack(){
  if(!pfFloatBack || detailStage.classList.contains('hidden') || !pfDetailHead){
    if(pfFloatBack) pfFloatBack.classList.remove('show');
    return;
  }
  const rect = pfDetailHead.getBoundingClientRect();
  pfFloatBack.classList.toggle('show', rect.bottom < 60);
}
if(pfFloatBack){
  window.addEventListener('scroll', updatePfFloatBack, { passive:true });
  pfFloatBack.addEventListener('click', closeCategory);
}
const pfSubInput = document.createElement('input');
pfSubInput.type = 'file'; pfSubInput.accept = 'image/*'; document.body.appendChild(pfSubInput);
let activeSubKey = null;
pfSubInput.addEventListener('change', ()=>{
  const file = pfSubInput.files[0]; if(!file || !activeSubKey) return;
  const reader = new FileReader();
  reader.onload = (e)=>{
    if(!subImages[activeSubKey]) subImages[activeSubKey] = [];
    if(!Array.isArray(subImages[activeSubKey])) subImages[activeSubKey] = [subImages[activeSubKey]];
    subImages[activeSubKey].push(e.target.result);
    const thumb = subGrid.querySelector('.sub-thumb[data-key="'+activeSubKey+'"]');
    if(thumb){ const img = thumb.querySelector('img'); img.src = e.target.result; img.classList.add('img-reveal','in'); thumb.classList.add('has-img'); }
  };
  reader.readAsDataURL(file);
});

/* ===== URL ROUTING & SHARE ===== */
let scrollPos = 0;
let scrollLocked = false;
function lockScroll(){
  if(scrollLocked) return;            // idempotent: never re-capture while already locked
  scrollLocked = true;
  scrollPos = window.scrollY;
  document.body.style.position = 'fixed';
  document.body.style.top = '-'+scrollPos+'px';
  document.body.style.left = '0';
  document.body.style.right = '0';
  document.body.style.overflow = 'hidden';
}
function unlockScroll(){
  if(!scrollLocked) return;           // no-op if not locked (prevents jump-to-top on stray calls)
  scrollLocked = false;
  document.body.style.position = '';
  document.body.style.top = '';
  document.body.style.left = '';
  document.body.style.right = '';
  document.body.style.overflow = '';
  window.scrollTo(0, scrollPos);
}
function updateURL(cat, item){
  const p = new URLSearchParams();
  if(cat) p.set('cat', cat);
  if(item!==undefined && item!==null) p.set('item', item);
  const qs = p.toString();
  const url = qs ? window.location.pathname+'?'+qs : window.location.pathname;
  window.history.replaceState({cat,item}, '', url);
}
function getShareURL(){ return window.location.href; }
async function copyCurrentURL(){
  const btn = document.activeElement;
  try {
    await navigator.clipboard.writeText(getShareURL());
    if(btn){
      btn.classList.add('copied');
      const orig = btn.innerHTML;
      btn.innerHTML = '<i class="fa-solid fa-check"></i> Copied!';
      setTimeout(()=>{ btn.innerHTML = orig; btn.classList.remove('copied'); }, 2000);
    }
  } catch { prompt('Copy this link:', getShareURL()); }
}
async function shareCurrent(){
  const url = getShareURL();
  if(navigator.share){
    try { await navigator.share({url}); } catch {}
  } else { copyCurrentURL(); }
}
document.getElementById('catShareBtn').addEventListener('click', shareCurrent);
document.getElementById('catCopyBtn').addEventListener('click', copyCurrentURL);

(function(){
  const lightbox = document.getElementById('lightbox');
  const backdrop = document.getElementById('lightboxBackdrop');
  const closeBtn = document.getElementById('lightboxClose');
  const lbImg = document.getElementById('lbImg');
  const lbMedia = document.getElementById('lbMedia');
  const lbCat = document.getElementById('lbCat');
  const lbTitle = document.getElementById('lbTitle');
  const lbDesc = document.getElementById('lbDesc');
  const lbTools = document.getElementById('lbTools');
  const lbPrev = document.getElementById('lbPrev');
  const lbNext = document.getElementById('lbNext');
  const lbVideo = document.getElementById('lbVideo');
  const lbVideoIframe = document.getElementById('lbVideoIframe');
  let lbSubIndex = 0;
  let lbImgIndex = 0;

  function render(idx){
    const cat = CATEGORIES[currentCatIdx];
    lbSubIndex = (idx + cat.items.length) % cat.items.length;
    const name = cat.items[lbSubIndex];
    const key = cat.key+':'+lbSubIndex;
    lbCat.textContent = cat.title;
    lbTitle.textContent = name;
    const imgs = subImages[key];
    const imgArr = Array.isArray(imgs) ? imgs : (imgs ? [imgs] : []);
    lbMedia.classList.remove('has-img','has-video');
    lbVideoIframe.src = '';
    if(imgArr.length > 0){
      lbImgIndex = Math.min(lbImgIndex, imgArr.length - 1);
      const item = imgArr[lbImgIndex];
      if(typeof item === 'string' && item.startsWith('yt::')){
        lbVideoIframe.src = 'https://www.youtube.com/embed/'+item.slice(4)+'?autoplay=1&rel=0';
        lbMedia.classList.add('has-video');
        lbDesc.textContent = 'Video preview — Part of the '+cat.title+' service line.';
      } else {
        lbImg.src = item;
        lbImg.alt = cat.title + ' project preview';
        lbMedia.classList.add('has-img');
        if(imgArr.length > 1){
          lbDesc.textContent = (lbImgIndex+1)+' of '+imgArr.length+' — Part of the '+cat.title+' service line.';
        } else {
          lbDesc.textContent = 'Part of the '+cat.title+' service line.';
        }
      }
    } else {
      lbImgIndex = 0;
      lbImg.removeAttribute('src');
      lbDesc.textContent = 'Part of the '+cat.title+' service line.';
    }
    lbTools.innerHTML = '';
  }
  function open(idx){
    render(idx);
    lightbox.classList.add('open');
    lightbox.setAttribute('aria-hidden','false');
    lockScroll();
    const cat = CATEGORIES[currentCatIdx];
    updateURL(cat.key, lbSubIndex);
  }
  function close(){
    lightbox.classList.remove('open');
    lightbox.setAttribute('aria-hidden','true');
    lbVideoIframe.src = '';
    unlockScroll();
    updateURL(!detailStage.classList.contains('hidden') ? CATEGORIES[currentCatIdx].key : null);
  }
  subGrid.addEventListener('click', (e)=>{
    const uploadBtn = e.target.closest('.sub-upload-btn');
    if(uploadBtn){
      e.preventDefault(); e.stopPropagation();
      activeSubKey = uploadBtn.dataset.key;
      pfSubInput.click();
      return;
    }
    const card = e.target.closest('.sub-card');
    if(!card) return;
    e.preventDefault();
    const idx = +card.querySelector('.sub-thumb').dataset.key.split(':')[1];
    const link = getPortfolioLink(CATEGORIES[currentCatIdx].key, idx);
    if(link){ window.open(link, '_blank', 'noopener'); return; }
    open(idx);
  });
  closeBtn.addEventListener('click', close);
  backdrop.addEventListener('click', close);

  function navPrev(){
    const cat = CATEGORIES[currentCatIdx];
    const key = cat.key+':'+lbSubIndex;
    const imgs = subImages[key];
    const imgArr = Array.isArray(imgs) ? imgs : (imgs ? [imgs] : []);
    if(imgArr.length > 1 && lbImgIndex > 0){ lbImgIndex--; render(lbSubIndex); }
    else { lbImgIndex = 0; render(lbSubIndex-1); }
  }
  function navNext(){
    const cat = CATEGORIES[currentCatIdx];
    const key = cat.key+':'+lbSubIndex;
    const imgs = subImages[key];
    const imgArr = Array.isArray(imgs) ? imgs : (imgs ? [imgs] : []);
    if(imgArr.length > 1 && lbImgIndex < imgArr.length - 1){ lbImgIndex++; render(lbSubIndex); }
    else { lbImgIndex = 0; render(lbSubIndex+1); }
  }
  lbPrev.addEventListener('click', navPrev);
  lbNext.addEventListener('click', navNext);
  document.getElementById('lbShareBtn').addEventListener('click', shareCurrent);
  document.getElementById('lbCopyBtn').addEventListener('click', copyCurrentURL);
  document.addEventListener('keydown', (e)=>{
    if(!lightbox.classList.contains('open')) return;
    if(e.key === 'Escape') close();
    if(e.key === 'ArrowLeft') navPrev();
    if(e.key === 'ArrowRight') navNext();
  });
})();

const WHY = [
  ['fa-lightbulb','Creative & Strategic Thinking','Every concept starts with your goals and audience, not a trend — so the creative direction behind your logo, video, or campaign is backed by real strategy, not guesswork.'],
  ['fa-medal','High-Quality Results','From first draft to final export, every file is checked for colour accuracy, clean typography, and pixel-level polish — work ready to print or publish without a second pass.'],
  ['fa-bullseye','Brand-Focused Design','Logos, social posts, videos, and ad creatives all pull from the same colour palette, type system, and voice, so your brand reads as one cohesive story across every platform.'],
  ['fa-comments','Professional Communication','Regular progress updates, straight answers on what is realistic, and no disappearing after the brief is signed off — you always know exactly where a project stands.'],
  ['fa-clock','On-Time Delivery','Launch dates, ad campaigns, and upload schedules are treated as hard deadlines, with buffer built into every timeline so delays on my end never become delays on yours.'],
  ['fa-sliders','Customized Solutions','No drag-and-drop templates or recycled layouts — every logo, edit, and campaign is designed from scratch around your brand, your audience, and what you are actually trying to achieve.'],
  ['fa-handshake','Long-Term Collaboration','Most clients return for the next logo, video, or campaign instead of starting over with someone new, because the brand is learned once and built on with every project after.'],
  ['fa-magnifying-glass','Detail-Oriented Workflow','Alignment, spacing, colour consistency, caption timing, export settings — the small details that make work look amateur when missed are checked twice before anything is marked done.']
];
const whyColors = ['wi-blue','wi-purple','wi-cyan','wi-pink','wi-blue','wi-purple','wi-cyan','wi-pink'];
const whyGrid = document.getElementById('whyGrid');

const heroCard = document.createElement('div');
heroCard.className = 'card why-card why-hero glow-border tilt spot reveal-scale';
heroCard.innerHTML = `
  <div class="spot-glow"></div><div class="sheen"></div>
  <div class="why-hero-left">
    <div class="why-hero-eyebrow">Why Work With Me</div>
    <div class="why-hero-title">A partner invested<br>in <em>your outcome</em></div>
    <div class="why-hero-desc">I don't just deliver files — I invest in understanding your vision, your audience, and your goals. Every project is a collaboration built on trust, transparency, and a relentless drive to exceed expectations.</div>
  </div>
  <div class="why-hero-stats">
    <div class="why-hero-stat"><div class="why-hero-stat-num">120+</div><div class="why-hero-stat-lbl">Projects Delivered</div></div>
    <div class="why-hero-stat"><div class="why-hero-stat-num">99%</div><div class="why-hero-stat-lbl">Client Satisfaction</div></div>
    <div class="why-hero-stat"><div class="why-hero-stat-num">3+</div><div class="why-hero-stat-lbl">Years Experience</div></div>
    <div class="why-hero-stat"><div class="why-hero-stat-num">24h</div><div class="why-hero-stat-lbl">Avg Response Time</div></div>
  </div>`;
whyGrid.appendChild(heroCard);
revealIO.observe(heroCard);

WHY.forEach(([icon,title,desc],idx)=>{
  const c = document.createElement('div');
  c.className = 'card why-card glow-border tilt spot reveal-scale';
  c.style.setProperty('--i', idx+1);
  c.innerHTML = `<div class="spot-glow"></div><div class="sheen"></div><div class="why-idx">0${idx+1}</div><div class="why-ic ${whyColors[idx]}"><i class="fa-solid ${icon}"></i></div><h4>${title}</h4><p>${desc}</p>`;
  whyGrid.appendChild(c);
  revealIO.observe(c);
});

const form = document.getElementById('contactForm');
const success = document.getElementById('formSuccess');
const ffFields = document.querySelectorAll('#contactForm .field.ff');
function validateFF(field){
  const input = field.querySelector('input, textarea');
  let valid = input.value.trim().length > 0;
  if(valid && input.type === 'email'){ valid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim()); }
  field.classList.toggle('valid', valid);
  return valid;
}
ffFields.forEach(field=>{
  const input = field.querySelector('input, textarea');
  input.addEventListener('input', ()=>{ field.classList.remove('invalid'); validateFF(field); });
  input.addEventListener('blur', ()=>{ if(input.value.trim().length>0 && !validateFF(field)){ field.classList.add('invalid'); } });
});
const CONTACT_EMAIL = 'hello.rafidzaman@gmail.com';

/* ===== SEARCH ENGINE ===== */
(function(){
  var searchIdx = [];
  function addToIdx(group, label, items){
    items.forEach(function(item){
      searchIdx.push({ group:group, groupLabel:label, label:item.label, desc:item.desc, section:item.section, icon:item.icon });
    });
  }
  function esc(str){
    var d = document.createElement('div'); d.textContent = str; return d.innerHTML;
  }
  SKILLS.forEach(function(cat){
    cat.items.forEach(function(skill){
      searchIdx.push({ group:'Skills', groupLabel:cat.cat, label:skill[0], desc:'', section:'skills', icon:cat.icon });
    });
  });
  SERVICES.forEach(function(svc){
    searchIdx.push({ group:'Services', groupLabel:svc.cat, label:svc.title, desc:svc.desc, section:'services', icon:svc.icon });
    svc.tags.forEach(function(tag){
      searchIdx.push({ group:'Services', groupLabel:svc.cat, label:tag, desc:'Tag — ' + svc.title, section:'services', icon:svc.icon });
    });
  });
  CATEGORIES.forEach(function(cat){
    searchIdx.push({ group:'Portfolio', groupLabel:'Category', label:cat.title, desc:cat.desc, section:'portfolio', icon:cat.icon });
    cat.items.forEach(function(item){
      searchIdx.push({ group:'Portfolio', groupLabel:cat.title, label:item, desc:'', section:'portfolio', icon:cat.icon });
    });
  });
  WHY.forEach(function(w){
    searchIdx.push({ group:'Why Me', groupLabel:'', label:w[1], desc:w[2], section:'why', icon:w[0] });
  });
  function highlightText(text, query){
    var idx = text.toLowerCase().indexOf(query.toLowerCase());
    if(idx === -1) return esc(text);
    return esc(text.substring(0, idx)) + '<span class="highlight">' + esc(text.substring(idx, idx + query.length)) + '</span>' + esc(text.substring(idx + query.length));
  }
  var navSearchInput = document.getElementById('navSearchInput');
  var searchOverlay = document.getElementById('searchOverlay');
  var searchInput = document.getElementById('searchInput');
  var searchResults = document.getElementById('searchResults');
  var searchHint = document.getElementById('searchHint');
  var searchEmpty = document.getElementById('searchEmpty');
  var searchQuery = document.getElementById('searchQuery');
  var searchClear = document.getElementById('searchClear');
  var searchClose = document.getElementById('searchClose');
  var searchBackdrop = document.getElementById('searchBackdrop');
  var open = false;
  function openSearch(){
    open = true;
    searchOverlay.classList.add('open');
    searchOverlay.setAttribute('aria-hidden','false');
    document.body.classList.add('menu-open');
    lockScroll();
    setTimeout(function(){ searchInput.focus(); }, 100);
  }
  function closeSearch(){
    open = false;
    searchOverlay.classList.remove('open');
    searchOverlay.setAttribute('aria-hidden','true');
    document.body.classList.remove('menu-open');
    unlockScroll();
    searchInput.value = '';
    navSearchInput.value = '';
    searchResults.innerHTML = '';
    searchHint.hidden = false;
    searchEmpty.hidden = true;
    searchClear.classList.remove('show');
  }
  navSearchInput.addEventListener('focus', function(e){
    openSearch();
    navSearchInput.blur();
  });
  document.querySelector('.nav-search-wrap').addEventListener('click', function(){
    openSearch();
  });
  searchClose.addEventListener('click', closeSearch);
  searchBackdrop.addEventListener('click', closeSearch);
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape' && open) closeSearch();
    if((e.ctrlKey || e.metaKey) && e.key === 'k'){ e.preventDefault(); if(open) closeSearch(); else openSearch(); }
  });
  searchClear.addEventListener('click', function(){ searchInput.value = ''; searchInput.focus(); doSearch(''); });
  function doSearch(query){
    var trimmed = query.trim();
    if(!trimmed){
      searchResults.innerHTML = '';
      searchHint.hidden = false;
      searchEmpty.hidden = true;
      searchClear.classList.remove('show');
      return;
    }
    searchClear.classList.add('show');
    searchHint.hidden = true;
    searchEmpty.hidden = true;
    var q = trimmed.toLowerCase();
    var matched = searchIdx.filter(function(item){
      return item.label.toLowerCase().indexOf(q) !== -1 || item.desc.toLowerCase().indexOf(q) !== -1 || item.groupLabel.toLowerCase().indexOf(q) !== -1;
    });
    if(matched.length === 0){
      searchResults.innerHTML = '';
      searchQuery.textContent = esc(trimmed);
      searchEmpty.hidden = false;
      return;
    }
    var groups = {};
    matched.forEach(function(item){
      if(!groups[item.group]) groups[item.group] = [];
      groups[item.group].push(item);
    });
    var order = ['Skills','Services','Portfolio','Why Me'];
    var html = '';
    order.forEach(function(g){
      if(!groups[g]) return;
      html += '<div class="search-group"><div class="search-group-title">' + esc(g) + '</div>';
      groups[g].forEach(function(item){
        var iconHtml = item.icon.indexOf('fa-') === 0 ? '<i class="fa-solid ' + esc(item.icon) + '"></i>' : '<i class="fa-solid fa-tag"></i>';
        var desc = item.desc ? highlightText(item.desc, trimmed) : '';
        html += '<a class="search-item" data-section="' + esc(item.section) + '" href="#' + esc(item.section) + '">';
        html += '<div class="search-item-ic">' + iconHtml + '</div>';
        html += '<div class="search-item-info"><div class="search-item-title">' + highlightText(item.label, trimmed) + '</div>';
        if(desc) html += '<div class="search-item-desc">' + desc + '</div>';
        html += '</div><span class="search-item-action">Go to ' + esc(item.section) + '</span></a>';
      });
      html += '</div>';
    });
    searchResults.innerHTML = html;
    searchResults.querySelectorAll('.search-item').forEach(function(el){
      el.addEventListener('click', function(e){
        e.preventDefault();
        closeSearch();
        var section = el.dataset.section;
        var target = document.getElementById(section);
        if(target) target.scrollIntoView({ behavior:'smooth', block:'start' });
      });
    });
  }
  searchInput.addEventListener('input', function(){ doSearch(this.value); });
  searchInput.addEventListener('keydown', function(e){
    if(e.key === 'Enter'){
      var first = searchResults.querySelector('.search-item');
      if(first) first.click();
    }
  });
})();

form.addEventListener('submit', (e)=>{
  e.preventDefault();
  let allValid = true;
  ffFields.forEach(field=>{ if(!validateFF(field)){ field.classList.add('invalid'); allValid = false; } });
  if(!allValid) return;
  const btn = form.querySelector('button[type="submit"]');
  const original = btn.innerHTML;
  const name = document.getElementById('fName').value.trim();
  const email = document.getElementById('fEmail').value.trim();
  const subject = document.getElementById('fSubject').value.trim();
  const message = document.getElementById('fMessage').value.trim();
  const body = `Name: ${name}\nEmail: ${email}\n\n${message}`;
  btn.disabled = true;
  btn.classList.add('is-loading');
  btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Opening mail...';
  success.classList.add('show');
  if(window.__openCompose) window.__openCompose(CONTACT_EMAIL, subject, body);
  setTimeout(()=>{
    form.reset();
    ffFields.forEach(f=> f.classList.remove('valid','invalid'));
    btn.disabled = false; btn.classList.remove('is-loading'); btn.innerHTML = original;
  }, 1200);
  setTimeout(()=> success.classList.remove('show'), 7000);
});

/* ===== STAT COUNTER ANIMATION ===== */
(function(){
  const yearEl = document.querySelector('.stat-tile-num[data-auto-year]');
  if(yearEl){
    const startYear = 2023;
    const years = new Date().getFullYear() - startYear;
    yearEl.dataset.count = years;
    yearEl.textContent = years + (yearEl.dataset.suffix || '+');
  }
  const aboutCounters = document.querySelectorAll('.stat-tile .stat-tile-num');
  const counterIO = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        const target = +e.target.dataset.count; const suffix = e.target.dataset.suffix || '+'; let cur = 0;
        const step = ()=>{ cur += target/40; if(cur<target){ e.target.textContent = Math.floor(cur)+suffix; requestAnimationFrame(step); } else { e.target.textContent = target+suffix; } };
        step(); counterIO.unobserve(e.target);
      }
    });
  },{threshold:0.5});
  aboutCounters.forEach(el=> counterIO.observe(el));
})();

const toTop = document.getElementById('toTop');
window.addEventListener('scroll', ()=>{ toTop.classList.toggle('show', window.scrollY>500); });
toTop.addEventListener('click', ()=> window.scrollTo({top:0,behavior:'smooth'}));

/* ===== PARALLAX BLOBS ===== */
(function(){
  const blobs = Array.from(document.querySelectorAll('.ambient-blob, .about-blob'));
  if(!blobs.length) return;
  // Only elements currently near the viewport get their transform updated each
  // scroll frame — most sections (and their blurred blobs) are off-screen at
  // any given time, so this skips the bulk of the per-frame work for free.
  const visible = new Set();
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=> e.isIntersecting ? visible.add(e.target) : visible.delete(e.target));
  }, { rootMargin: '200px 0px' });
  blobs.forEach((b,i)=>{ b.dataset.pspeed = (i%3===0)?0.03:(i%3===1)?-0.02:0.04; io.observe(b); });
  let ticking = false;
  window.addEventListener('scroll', ()=>{
    if(!ticking && visible.size){
      requestAnimationFrame(()=>{
        const sy = window.scrollY;
        visible.forEach(b=>{ b.style.transform = 'translateY('+(sy*b.dataset.pspeed)+'px)'; });
        ticking = false;
      });
      ticking = true;
    }
  }, { passive:true });
})();

/* ===== PORTFOLIO STAT COUNTER ANIMATION ===== */
(function(){
  const pfNums = document.querySelectorAll('.pf-stat-pill .psp-num');
  if(!pfNums.length) return;
  const pfIO = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        const el = e.target;
        const raw = el.textContent.trim();
        const match = raw.match(/^(\d+)(.*)/);
        if(match){
          const target = parseInt(match[1]);
          const suffix = match[2] || '';
          let cur = 0;
          const dur = 900;
          const start = performance.now();
          const step = (now)=>{
            const t = Math.min((now-start)/dur,1);
            const eased = 1 - Math.pow(1-t,3);
            cur = Math.round(eased*target);
            el.textContent = cur+suffix;
            if(t<1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        }
        pfIO.unobserve(el);
      }
    });
  },{threshold:0.5});
  pfNums.forEach(el=> pfIO.observe(el));
})();

/* ===== WHY ME HERO STAT COUNTERS ===== */
(function(){
  const whNums = document.querySelectorAll('.why-hero-stat-num');
  if(!whNums.length) return;
  const whIO = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        const el = e.target;
        const raw = el.textContent.trim();
        const match = raw.match(/^(\d+)(.*)/);
        if(match){
          const target = parseInt(match[1]);
          const suffix = match[2] || '';
          let cur = 0;
          const dur = 1100;
          const start = performance.now();
          const step = (now)=>{
            const t = Math.min((now-start)/dur,1);
            const eased = 1 - Math.pow(1-t,3);
            cur = Math.round(eased*target);
            el.textContent = cur+suffix;
            if(t<1) requestAnimationFrame(step);
          };
          requestAnimationFrame(step);
        }
        whIO.unobserve(el);
      }
    });
  },{threshold:0.5});
  whNums.forEach(el=> whIO.observe(el));
})();

/* ===== SECTION TYPING REVEAL ON SCROLL ===== */
(function(){
  const subs = document.querySelectorAll('.section-sub');
  if(!subs.length) return;
  const subIO = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        e.target.classList.add('in');
        subIO.unobserve(e.target);
      }
    });
  },{threshold:0.3});
  subs.forEach(el=> subIO.observe(el));
})();

/* ===== PREMIUM MICRO-INTERACTIONS ===== */

/* Parallax floating glass elements on scroll */
(function(){
  const glasses = Array.from(document.querySelectorAll('.float-glass'));
  if(!glasses.length) return;
  const visible = new Set();
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=> e.isIntersecting ? visible.add(e.target) : visible.delete(e.target));
  }, { rootMargin: '200px 0px' });
  glasses.forEach((el,i)=>{ el.dataset.pspeed = (i%3===0)?0.04:(i%3===1)?-0.03:0.05; io.observe(el); });
  let ticking = false;
  window.addEventListener('scroll', ()=>{
    if(!ticking && visible.size){
      requestAnimationFrame(()=>{
        const scrollY = window.scrollY;
        visible.forEach(el=>{
          const speed = el.dataset.pspeed;
          el.style.transform = 'translateY('+(scrollY*speed)+'px) rotate('+(scrollY*0.02)+'deg)';
        });
        ticking = false;
      });
      ticking = true;
    }
  },{passive:true});
})();

/* ===== GLOBAL FLOATING PARTICLES ===== */
(function(){
  const canvas = document.getElementById('globalParticles');
  if(!canvas) return;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = window.matchMedia('(hover:none), (pointer:coarse)').matches;
  if(reduceMotion || coarse || window.innerWidth < 900){ canvas.remove(); return; }
  const ctx = canvas.getContext('2d');
  let w, h, particles = [];
  const COLORS = ['59,130,246','139,92,246','34,211,238','99,102,241','217,70,239'];
  function resize(){
    w = canvas.width = window.innerWidth;
    h = canvas.height = window.innerHeight;
  }
  function init(){
    resize();
    const count = Math.min(40, Math.floor((w*h)/30000));
    particles = Array.from({length:count},()=>({
      x:Math.random()*w, y:Math.random()*h,
      r:Math.random()*1.8+0.5,
      vx:(Math.random()-0.5)*0.15, vy:(Math.random()-0.5)*0.15,
      c:COLORS[Math.floor(Math.random()*COLORS.length)],
      a:Math.random()*0.4+0.15, p:Math.random()*Math.PI*2
    }));
  }
  function tick(){
    ctx.clearRect(0,0,w,h);
    for(let i=0;i<particles.length;i++){
      for(let j=i+1;j<particles.length;j++){
        const a=particles[i], b=particles[j];
        const dx=a.x-b.x, dy=a.y-b.y, dist=Math.sqrt(dx*dx+dy*dy);
        if(dist < 160){
          const op = (1-dist/160)*0.08;
          ctx.beginPath(); ctx.moveTo(a.x,a.y); ctx.lineTo(b.x,b.y);
          ctx.strokeStyle='rgba('+a.c+','+op.toFixed(3)+')'; ctx.lineWidth=0.5;
          ctx.stroke();
        }
      }
    }
    particles.forEach(pt=>{
      pt.vx*=0.998; pt.vy*=0.998;
      pt.x+=pt.vx; pt.y+=pt.vy; pt.p+=0.015;
      if(pt.x<0)pt.x=w; if(pt.x>w)pt.x=0; if(pt.y<0)pt.y=h; if(pt.y>h)pt.y=0;
      const alpha=pt.a*(0.5+0.5*Math.sin(pt.p));
      ctx.beginPath(); ctx.arc(pt.x,pt.y,pt.r,0,Math.PI*2);
      ctx.fillStyle='rgba('+pt.c+','+alpha.toFixed(2)+')'; ctx.fill();
    });
    requestAnimationFrame(tick);
  }
  window.addEventListener('resize', resize);
  init(); tick();
})();

/* ===== MAGNETIC BUTTONS ===== */
(function(){
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduceMotion) return;
  const els = document.querySelectorAll('.magnetic');
  if(!els.length) return;
  const STRENGTH = 0.35;
  const MAX_PULL = 14;
  els.forEach(el=>{
    let raf = null;
    el.addEventListener('mousemove', (e)=>{
      const r = el.getBoundingClientRect();
      let dx = (e.clientX - (r.left + r.width/2)) * STRENGTH;
      let dy = (e.clientY - (r.top + r.height/2)) * STRENGTH;
      dx = Math.max(-MAX_PULL, Math.min(MAX_PULL, dx));
      dy = Math.max(-MAX_PULL, Math.min(MAX_PULL, dy));
      if(raf) cancelAnimationFrame(raf);
      raf = requestAnimationFrame(()=>{
        el.style.transition = 'transform .15s ease-out';
        el.style.transform = 'translate('+dx+'px,'+dy+'px)';
      });
    }, {passive:true});
    el.addEventListener('mouseleave', ()=>{
      if(raf) cancelAnimationFrame(raf);
      el.style.transition = 'transform .6s var(--ease-spring)';
      el.style.transform = 'translate(0,0)';
    }, {passive:true});
  });
})();

/* ===== ELASTIC MICRO-INTERACTIONS ===== */
(function(){
  document.querySelectorAll('.btn').forEach(btn=>{
    btn.addEventListener('mousedown',()=>{ btn.style.transform='scale(0.95)'; });
    btn.addEventListener('mouseup',()=>{ btn.style.transform='scale(1)'; });
    btn.addEventListener('mouseleave',()=>{ btn.style.transform=''; });
  });
})();

/* ===== ENHANCED CARD TILT ===== */
(function(){
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduceMotion) return;
  function attachTilt(el){
    if(el.dataset.tiltBound) return;
    el.dataset.tiltBound='1';
    el.addEventListener('mousemove',(e)=>{
      if(el.classList.contains('open')) return;
      const r=el.getBoundingClientRect();
      const x=(e.clientX-r.left)/r.width-0.5;
      const y=(e.clientY-r.top)/r.height-0.5;
      el.style.transform='perspective(900px) rotateY('+(x*8)+'deg) rotateX('+(y*-8)+'deg) translateY(-6px)';
    });
    el.addEventListener('mouseleave',()=>{
      if(el.classList.contains('open')) return;
      el.style.transform='perspective(900px) rotateY(0) rotateX(0) translateY(0)';
      el.style.transition='transform .6s var(--ease-spring)';
      setTimeout(()=>{ el.style.transition=''; },600);
    });
  }
  document.querySelectorAll('.tilt').forEach(attachTilt);
  const obs=new MutationObserver(()=>{
    document.querySelectorAll('.tilt:not([data-tilt-bound])').forEach(attachTilt);
  });
  obs.observe(document.body,{childList:true,subtree:true});
})();

/* ===== SMOOTH SCROLLBAR FOR LIGHTBOX ===== */
(function(){
  const panels = document.querySelectorAll('.lightbox-panel');
  panels.forEach(p=>{
    p.style.scrollBehavior='smooth';
    p.style.scrollbarWidth='thin';
    p.style.scrollbarColor='rgba(139,92,246,0.3) transparent';
  });
})();

/* ============================================================
   PREMIUM ANIMATION ENHANCEMENTS (JS)
   ============================================================ */
(function(){
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* --- Buttery page transition --- */
  const page = document.getElementById('page');
  if(page){
    requestAnimationFrame(()=> requestAnimationFrame(()=> page.classList.add('ready')));
  }

  /* --- Hero entrance: handled by CSS (.hero .reveal heroEnter animation) --- */

  /* --- Staggered word reveal for section titles --- */
  if(!reduceMotion){
    document.querySelectorAll('.section-title').forEach(title=>{
      if(title.querySelector('.word-reveal')) return;
      if(title.querySelector('span')) return; // skip titles with nested gradient spans (avoid breaking bg-clip text)
      const frag = document.createDocumentFragment();
      let wi = 0;
      title.textContent.split(/(\s+)/).forEach(w=>{
        if(w.trim()===''){ frag.appendChild(document.createTextNode(w)); return; }
        const wrap = document.createElement('span');
        wrap.className = 'word-reveal';
        const inner = document.createElement('span');
        inner.textContent = w; inner.style.setProperty('--wi', wi++);
        wrap.appendChild(inner); frag.appendChild(wrap);
      });
      title.innerHTML = '';
      title.appendChild(frag);
    });
    const wrIO = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); wrIO.unobserve(e.target); } });
    }, { threshold:0.25 });
    document.querySelectorAll('.word-reveal').forEach(w=> wrIO.observe(w.parentElement || w));
  }

  /* --- Image smooth reveal (fade + scale) --- */
  if(!reduceMotion){
    document.querySelectorAll('.pfp-circle img, .sub-thumb.has-img img').forEach(img=>{
      img.classList.add('img-reveal');
    });
    const imgIO = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); imgIO.unobserve(e.target); } });
    }, { threshold:0.1 });
    document.querySelectorAll('.img-reveal').forEach(img=> imgIO.observe(img));
  }

  /* --- Hero mouse parallax (desktop, subtle) --- */
  const fine = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  if(fine && !reduceMotion){
    const hero = document.querySelector('.hero');
    const targets = [
      { el:document.querySelector('.hero-bg'), depth:14 },
      { el:document.querySelector('.hero-mesh'), depth:26 },
      { el:document.querySelector('.hero-grid'), depth:8 }
    ].filter(t=>t.el);
    targets.forEach(t=> t.el.classList.add('hero-parallax'));
    let raf = null, tx = 0, ty = 0, cx = 0, cy = 0;
    hero && hero.addEventListener('mousemove', (e)=>{
      const r = hero.getBoundingClientRect();
      tx = ((e.clientX - r.left)/r.width - 0.5);
      ty = ((e.clientY - r.top)/r.height - 0.5);
      if(!raf) raf = requestAnimationFrame(loop);
    });
    hero && hero.addEventListener('mouseleave', ()=>{ tx = 0; ty = 0; if(!raf) raf = requestAnimationFrame(loop); });
    function loop(){
      cx += (tx - cx)*0.08; cy += (ty - cy)*0.08;
      targets.forEach(t=>{ t.el.style.transform = 'translate3d('+(cx*t.depth).toFixed(2)+'px,'+(cy*t.depth).toFixed(2)+'px,0)'; });
      if(Math.abs(tx-cx)>0.001 || Math.abs(ty-cy)>0.001){ raf = requestAnimationFrame(loop); } else { raf = null; }
    }
  }

  /* --- Email links → open Gmail compose (reliable across PC, laptop, mobile, tablet) --- */
  (function(){
    function openCompose(to, subject, body){
      const p = new URLSearchParams();
      p.set('view','cm'); p.set('fs','1'); p.set('to', to);
      if(subject) p.set('su', subject);
      if(body) p.set('body', body);
      const win = window.open('https://mail.google.com/mail/?' + p.toString(), '_blank', 'noopener');
      /* Popup blocked (win is null/undefined, or immediately closed) → fall back
         to a plain mailto: link so the message still reaches the user's own
         default mail app instead of silently failing. */
      if(!win || win.closed || typeof win.closed === 'undefined'){
        const mp = new URLSearchParams();
        if(subject) mp.set('subject', subject);
        if(body) mp.set('body', body);
        const qs = mp.toString();
        window.location.href = 'mailto:' + to + (qs ? ('?' + qs) : '');
      }
    }
    window.__openCompose = openCompose;
    document.addEventListener('click', (e)=>{
      const a = e.target.closest('a[href^="mailto:"]');
      if(!a) return;
      e.preventDefault();
      try{
        const href = a.getAttribute('href');
        const m = href.match(/^mailto:([^?]+)(?:\?(.*))?$/);
        const to = m ? decodeURIComponent(m[1]) : '';
        let subject = '', body = '';
        if(m && m[2]){ const sp = new URLSearchParams(m[2]); subject = sp.get('subject') || ''; body = sp.get('body') || ''; }
        openCompose(to, subject, body);
      }catch(err){
        window.location.href = a.getAttribute('href');
      }
    });
  })();

  /* --- Smooth scrolling for anchor links (ease) --- */
  window.fxScrollToId = function(id){
    if(!id || id.length < 2) return;
    const target = document.getElementById(id.slice(1)) || document.querySelector(id);
    if(!target) return;
    const navH = (document.getElementById('navbar') || { offsetHeight: 0 }).offsetHeight;
    const y = Math.max(0, window.scrollY + target.getBoundingClientRect().top - navH - 14);
    if(window.__fxScrollTo){ window.__fxScrollTo(y); }
    else { window.scrollTo({ top: y, behavior: (window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth') }); }
  }
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', (e)=>{
      const id = a.getAttribute('href');
      if(!id || id.charAt(0) !== '#' || id.length < 2) return;
      if(!document.querySelector(id)) return;
      e.preventDefault();
      window.fxScrollToId(id);
    });
  });
})();

/* ============================================================
   FX ENGINE — momentum smooth scroll, loader handoff, depth (additive)
   ============================================================ */
(function(){
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = window.matchMedia('(hover:none), (pointer:coarse)').matches;

  /* --- Cinematic loader → page handoff (with safety timeout so a hung
     resource can never leave the preloader / pageReveal covering the page) --- */
  const preloader = document.getElementById('preloader');
  const pageReveal = document.getElementById('pageReveal');
  let loaded = false;
  function finishLoad(){
    if(loaded) return; loaded = true;
    if(preloader) preloader.classList.add('hide');
    if(pageReveal) requestAnimationFrame(()=> pageReveal.classList.add('done'));
  }
  if(preloader){
    if(document.readyState === 'complete'){ setTimeout(finishLoad, 350); }
    else { window.addEventListener('load', ()=> setTimeout(finishLoad, 350)); }
    // Safety net: never let the overlay trap the page
    setTimeout(finishLoad, 3500);
  } else { finishLoad(); }

  if(reduce) return; // no virtual scroll under reduced motion
  if(coarse) return; // skip momentum engine on touch/mobile — use native scroll

  /* --- Momentum smooth-scroll engine (Lenis-style, vanilla) --- */
  let target = window.scrollY || 0;
  let current = target;
  let rafId = null;
  let running = false;
  const EASE = 0.085;           // lower = smoother / more momentum
  const MAX_DELTA = 120;        // clamp per-frame step for stability

  function loop(){
    const diff = target - current;
    if(Math.abs(diff) < 0.4){
      current = target;
      window.scrollTo(0, current);
      running = false; rafId = null; return;
    }
    let step = diff * EASE;
    if(step > MAX_DELTA) step = MAX_DELTA;
    else if(step < -MAX_DELTA) step = -MAX_DELTA;
    current += step;
    window.scrollTo(0, current);
    rafId = requestAnimationFrame(loop);
  }
  function start(){ if(!running){ running = true; rafId = requestAnimationFrame(loop); } }

  // Intercept wheel for momentum (desktop, fine pointer)
  if(!coarse){
    window.addEventListener('wheel', (e)=>{
      // Let native scroll work inside scrollable overlays (lightbox, etc.)
      const over = e.target;
      if(over && over.closest && over.closest('.lightbox.open, .lightbox-panel, [data-fx-native-scroll], .service-detail.open .sd-panel')) return;
      if(document.body.classList.contains('menu-open')) return;
      e.preventDefault();
      target += e.deltaY * (e.deltaMode === 1 ? 24 : 1);
      const max = document.documentElement.scrollHeight - window.innerHeight;
      target = Math.max(0, Math.min(max, target));
      start();
    }, { passive:false });
  }

  // Touch: use native momentum, but keep target synced
  window.addEventListener('touchmove', ()=>{ target = window.scrollY; current = window.scrollY; }, { passive:true });
  window.addEventListener('touchstart', ()=>{ target = window.scrollY; current = window.scrollY; }, { passive:true });

  // Any programmatic / scrollbar / anchor scroll syncs the engine
  window.addEventListener('scroll', ()=>{ if(!running){ target = window.scrollY; current = window.scrollY; } }, { passive:true });
  window.addEventListener('keydown', (e)=>{
    if(['PageDown','PageUp','Home','End','ArrowDown','ArrowUp','Space'].includes(e.code)){
      target = window.scrollY; current = window.scrollY;
    }
  });

  document.documentElement.classList.add('fx-smooth');

  /* Route scrollIntoView({behavior:'smooth'}) through the momentum engine
     (used by nav, rail dots, "back to top", etc.) — but never hijack inner scroll areas. */
  const _origScrollIntoView = Element.prototype.scrollIntoView;
  Element.prototype.scrollIntoView = function(opts){
    const isSmooth = opts && (opts === 'smooth' || (opts.behavior === 'smooth'));
    const inModal = this.closest && this.closest('.lightbox.open, .lightbox-panel, [data-fx-native-scroll]');
    if(isSmooth && window.__fxScrollTo && !inModal){
      const y = window.scrollY + this.getBoundingClientRect().top - 10;
      window.__fxScrollTo(y);
      return;
    }
    return _origScrollIntoView.apply(this, arguments);
  };
  /* Only expose the engine-driven scroll on fine pointers; on coarse/touch
     devices window.__fxScrollTo stays undefined so the scrollIntoView override
     falls back to native momentum scrolling (no engine jank on touch). */
  if(!coarse){
    window.__fxScrollTo = (y)=>{ target = Math.max(0, Math.min(document.documentElement.scrollHeight - window.innerHeight, y)); start(); };
  }

  /* --- Subtle global mouse parallax on background depth layers --- */
  const fine = window.matchMedia('(hover:hover) and (pointer:fine)').matches;
  if(fine && !coarse){
    const orbs = document.querySelector('.bg-orbs');
    const fxWrap = document.createElement('div');
    fxWrap.className = 'fx-mesh-wrap';
    const mesh = document.querySelector('.fx-mesh');
    if(mesh && mesh.parentNode){ mesh.parentNode.insertBefore(fxWrap, mesh); fxWrap.appendChild(mesh); }
    let rx = 0, ry = 0, cx = 0, cy = 0, praf = null;
    window.addEventListener('mousemove', (e)=>{
      rx = (e.clientX / window.innerWidth - 0.5);
      ry = (e.clientY / window.innerHeight - 0.5);
      if(!praf) praf = requestAnimationFrame(pmove);
    }, { passive:true });
    function pmove(){
      cx += (rx - cx) * 0.05; cy += (ry - cy) * 0.05;
      if(fxWrap) fxWrap.style.transform = 'translate3d(' + (cx*-22) + 'px,' + (cy*-22) + 'px,0)';
      if(orbs) orbs.style.transform = 'translate3d(' + (cx*14) + 'px,' + (cy*14) + 'px,0)';
      if(Math.abs(rx-cx) > 0.001 || Math.abs(ry-cy) > 0.001){ praf = requestAnimationFrame(pmove); } else { praf = null; }
    }
  }

  /* --- Farewell fade on unload (exit animation) --- */
  window.addEventListener('beforeunload', ()=>{
    document.body.style.transition = 'opacity .4s ease';
    document.body.style.opacity = '0';
  });
})();

/* ===== ON-LOAD URL ROUTING ===== */
(function(){
  const params = new URLSearchParams(window.location.search);
  const catKey = params.get('cat');
  const itemIdx = params.get('item');
  if(!catKey) return;
  const ci = CATEGORIES.findIndex(c => c.key === catKey);
  if(ci === -1) return;
  if(!detailStage.classList.contains('hidden')) closeCategory();
  setTimeout(() => {
    openCategory(ci);
    if(itemIdx !== null && itemIdx !== undefined){
      setTimeout(() => {
        const cards = subGrid.querySelectorAll('.sub-card');
        const idx = parseInt(itemIdx, 10);
        if(!isNaN(idx) && cards[idx]){
          cards[idx].click();
        }
      }, 400);
    }
  }, 300);
})();
